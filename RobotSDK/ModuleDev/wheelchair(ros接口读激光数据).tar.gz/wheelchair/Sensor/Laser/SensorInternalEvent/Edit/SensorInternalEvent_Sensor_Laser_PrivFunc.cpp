//You need to program this file.

#include "../NoEdit/SensorInternalEvent_Sensor_Laser_PrivFunc.h"

//*******************Please add static libraries in .pro file*******************
//e.g. unix:LIBS += ... or win32:LIBS += ...

bool DECOFUNC(setParamsVarsOpenNode)(QString qstrConfigName, QString qstrNodeType, QString qstrNodeClass, QString qstrNodeName, void * paramsPtr, void * varsPtr)
{
	XMLDomInterface xmlloader(qstrConfigName,qstrNodeType,qstrNodeClass,qstrNodeName);
	SensorInternalEvent_Sensor_Laser_Params * params=(SensorInternalEvent_Sensor_Laser_Params *)paramsPtr;
	SensorInternalEvent_Sensor_Laser_Vars * vars=(SensorInternalEvent_Sensor_Laser_Vars *)varsPtr;
	/*======Please Program below======*/
	/*
	Function: open node.
	Procedure:
	1: load parameters (params). [GetParamValue(xmlloader,params,tag); GetEnumParamValue(xmlloader,params,tag); GetUEnumParamValue(xmlloader,params,tag)]
	2: initialize variables (vars).
	3: If everything is OK, return 1 for successful opening and vice versa.
	*/
    GetParamValue(xmlloader, vars, topic);
    GetParamValue(xmlloader, vars, queuesize);
    GetParamValue(xmlloader, vars, quryinterval);

    vars->lasersub->resetTopic(vars->topic, vars->queuesize);
    vars->lasersub->resetQueryInterval(vars->quryinterval);
    vars->lasersub->startReceiveSlot();
	return 1;
}

bool DECOFUNC(handleVarsCloseNode)(void * paramsPtr, void * varsPtr)
{
	SensorInternalEvent_Sensor_Laser_Params * params=(SensorInternalEvent_Sensor_Laser_Params *)paramsPtr;
	SensorInternalEvent_Sensor_Laser_Vars * vars=(SensorInternalEvent_Sensor_Laser_Vars *)varsPtr;
	/*======Please Program below======*/
	/*
	Function: close node.
	Procedure:
	1: handle/close variables (vars).
	2: If everything is OK, return 1 for successful closing and vice versa.
	*/
	
	return 1;
}

void DECOFUNC(getInternalTrigger)(void * paramsPtr, void * varsPtr, QObject * & internalTrigger, QString & internalTriggerSignal)
{
	SensorInternalEvent_Sensor_Laser_Params * params=(SensorInternalEvent_Sensor_Laser_Params *)paramsPtr;
	SensorInternalEvent_Sensor_Laser_Vars * vars=(SensorInternalEvent_Sensor_Laser_Vars *)varsPtr;
    internalTrigger=vars->lasersub;
    internalTriggerSignal=QString(SIGNAL(receiveMessageSignal()));
	/*======Occasionally Program above======*/
	/*
	Function: get internal trigger [defined in vars] for node.
	You need to program here when you need internal trigger (internalTrigger + internalTriggerSignal) for node.
	E.g.
	internalTrigger=&(vars->trigger);
	internalTriggerSignal=QString(SIGNAL(triggerSignal()));
	*/
}

void DECOFUNC(initializeOutputData)(void * paramsPtr, void * varsPtr, boost::shared_ptr<void> & outputDataPtr)
{
	SensorInternalEvent_Sensor_Laser_Params * params=(SensorInternalEvent_Sensor_Laser_Params *)paramsPtr;
	SensorInternalEvent_Sensor_Laser_Vars * vars=(SensorInternalEvent_Sensor_Laser_Vars *)varsPtr;
	outputDataPtr=boost::shared_ptr<void>(new SensorInternalEvent_Sensor_Laser_Data());
	/*======Occasionally Program below/above======*/
	/*
	Function: initial output data.
	You need to program here when you need to manually initialize output data.
	*/
	
}

bool DECOFUNC(generateSourceData)(void * paramsPtr, void * varsPtr, void * outputData, QList<int> & outputPortIndex, QTime & timeStamp)
{
	SensorInternalEvent_Sensor_Laser_Params * params=(SensorInternalEvent_Sensor_Laser_Params *)paramsPtr;
	SensorInternalEvent_Sensor_Laser_Vars * vars=(SensorInternalEvent_Sensor_Laser_Vars *)varsPtr;
	SensorInternalEvent_Sensor_Laser_Data * outputdata=(SensorInternalEvent_Sensor_Laser_Data *)outputData;
	outputPortIndex=QList<int>();
	timeStamp=QTime();
	/*======Please Program below======*/
	/*
	Step 1: fill outputdata.
	Step 2 [optional]: determine the outputPortIndex. (if not, outputdata will be sent by all ports)
	E.g. outputPortIndex=QList<int>()<<(outportindex1)<<(outportindex2)...
	Step 3: set the timeStamp for Simulator.
	*/
    outputdata->laserPtr = vars->lasersub->getMessage();
    if(outputdata->laserPtr == NULL)
    {
        return 0;
    }
    int msec=(outputdata->laserPtr->header.stamp.sec)%(24*60*60)*1000+(outputdata->laserPtr->header.stamp.nsec)/1000000;
    outputdata->timestamp=QTime::fromMSecsSinceStartOfDay(msec);
    outputdata->datasize = outputdata->laserPtr->ranges.size();
    outputdata->angle_min = outputdata->laserPtr->angle_min;
    outputdata->angle_max = outputdata->laserPtr->angle_max;


    //memcpy(outputdata->laserdata, outputdata->laserPtr->ranges.data(), outputdata->laserPtr->ranges.size());
    for(int i=0; i<outputdata->datasize; i++)
    {
        outputdata->laserdata[i] = outputdata->laserPtr->ranges[i];
    }
	return 1;
}

