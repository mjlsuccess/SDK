#ifndef WHEELCHAIR_H
#define WHEELCHAIR_H

#include "wheelchair_global.h"

class WHEELCHAIRSHARED_EXPORT Wheelchair
{

public:
    Wheelchair();
};

#endif // WHEELCHAIR_H
