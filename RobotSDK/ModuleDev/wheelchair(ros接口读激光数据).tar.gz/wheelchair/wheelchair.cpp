#include "wheelchair.h"


Wheelchair::Wheelchair()
{
}
